public class Request {
    String area;
    String course;
    int expectedFees;
    int noOfDays;

    public Request(String area, String course, int expectedFees, int noOfDays) {
        this.area = area;
        this.course = course;
        this.expectedFees = expectedFees;
        this.noOfDays = noOfDays;
    }

    public String toString(){
        return "Area: "+this.area+" Course: "+this.course+" Expected Fees: "+this.expectedFees+" No of Days: "+this.noOfDays;
    }
}
