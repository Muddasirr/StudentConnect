import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class TeacherList{
    static boolean flag = true;
    ArrayList<Teacher> TeacherList = new ArrayList<Teacher>();
    public void insert(Teacher T) throws IOException {
        if(!find(T.name,T.age)) {
            this.TeacherList.add(T);
            if (flag) {
                FileWriter FW = new FileWriter("Data.txt", true);
                FW.write(T.name + " " + T.age + " " + T.experience.years + " " + T.experience.months + " " + T.area + " " + T.course + "\n");
                FW.close();
                KeyList.AssignKey(T);
            }else{
                KeyList.AssignKey(T,Directory.key);
            }
        }
    }
    public String toString(){
        StringBuilder x = new StringBuilder();
        int i = 0;
        for (Teacher teacher : TeacherList) {
            i++;
            x.append((i) + " ").append(teacher).append("\n");
        }
        return x.toString();
    }
    public boolean find(String name,int age){
        for (Teacher teacher : TeacherList) {
            if (teacher.name.equals(name) && teacher.age == age)
                return true;
        }
        return false;
    }
}
