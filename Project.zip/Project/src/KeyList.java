import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;

public class KeyList{
    static HashMap<String,Teacher> KeyList = new HashMap<String, Teacher>();
    static boolean flag = true;
    public static void AssignKey(Teacher T) throws IOException {
        String K = "";
        do {
            K = generateKey();
        } while (KeyList.get(K)!=null);
        AssignKey(T,K);
        FileWriter FW = new FileWriter("Keys.txt",true);
        FW.write(K+" ");
        FW.close();
    }
    public static void AssignKey(Teacher T,String K) throws IOException {
        KeyList.put(K,T);
        if(flag) {
            System.out.println(K);
        }
    }
    public static String generateKey(){
        String S = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz";
        StringBuilder SB = new StringBuilder(5);
        for (int i = 0;i<5;i++ ) {
            int a = (int) (Math.random()*S.length());
            SB.append(S.charAt(a));
        }
        return SB.toString();
    }
}
