import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception {
        Directory D = new Directory();
        Scanner S = new Scanner(System.in);
        String s;
        do {
            System.out.println("Student or Teacher: ");
            System.out.println("Enter S or T");
            s = S.next();
        } while (!s.equals("S")&&!s.equals("T"));
        if(s.equals("T")){
            do{
                System.out.println("Enter SU to Sign Up SI for Sign In:");
                s = S.next();
            }while (!s.equals("SI")&&!s.equals("SU"));
            if (s.equals("SU")){
                System.out.println("Answer these questions to sign up as an tutor");
                System.out.println();
                System.out.println("Enter Your First Name: ");
                String name1 = S.next();
                System.out.println("Enter Your Last Name: ");
                String name2 = S.next();
                String name = name1+" "+name2;
                System.out.println("The course you want to Teach?");
                String course1 = S.next();
                System.out.println("Area  availability: ");
                String Area1 = S.next();
                System.out.println("How old are you?");
                int Age1 = S.nextInt();
                System.out.println("Teaching experience if any.");
                System.out.print("Years: ");
                int exp = S.nextInt();
                System.out.print("Months: ");
                int exp1 = S.nextInt();
                Exp e = new Exp(exp, exp1);
                System.out.println("Press 1 to submit");
                Integer num1 = S.nextInt();
                if (num1 == 1) {
                    System.out.println("Your form has been submitted. The Following is your Unique key to register");
                    D.insert(name,Age1,exp,exp1,Area1,course1);
                }
            }
            else {
                System.out.println("Enter your key: ");
                s = S.next();
                Teacher T = KeyList.KeyList.get(s);
                if (T!=null){
                    System.out.println("You have successfully Logged In\n");
                    do {
                        System.out.println("Enter S for Students or R for Requests");
                        s = S.next();
                    } while(!s.equals("S")&&!s.equals("R"));
                    if(s.equals("S")){
                        StudentList St = D.StudentMap.get(T);
                        System.out.println(St);
                    }else{
                        RequestList Rs = D.RequestMap.get(T);
                        System.out.println(Rs);
                        do {
                            System.out.println("Do you wish to accept any requests?\nEnter Y or N: ");
                            s = S.next();
                        } while (!s.equals("Y")&&!s.equals("N"));
                        if(s.equals("N")){
                            System.out.println("Exit");
                        }else{
                            System.out.println("Enter Request Index: ");
                            s = S.next();
                            int a = Integer.parseInt(s);
                            int i = D.RequestMap.get(T).IndexList.get(a-1);
                            D.acceptRequest(i,T.area,T.course,a-1);
                            System.out.println("Student successfully added!");
                        }
                    }
                }

            }
        }
        else{
            System.out.println("Enter Area: ");
            String area = S.next();
            System.out.println("Enter Course: ");
            String course = S.next();
            if(D.search(area,course)!=null){
                System.out.println(D.search(area,course));
                System.out.println("Enter Index of Teacher: ");
                int index = S.nextInt();
                System.out.println("Enter Expected Fees: ");
                int fees = S.nextInt();
                System.out.println("Enter No of Days: ");
                int days = S.nextInt();
                D.addRequest(index-1,area,course,fees,days);
                System.out.println("Your Request has been Generated!");
            }
        }
    }
}
