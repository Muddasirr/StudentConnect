import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

public class Directory {
    HashMap<Integer,CourseList> AreaList = new HashMap<Integer, CourseList>();
    HashMap<Teacher,RequestList> RequestMap = new HashMap<Teacher, RequestList>();
    HashMap<Teacher,StudentList> StudentMap = new HashMap<Teacher, StudentList>();
    static String key;
    public Directory() throws IOException {
        Scanner SC = new Scanner(new File("Data.txt"));
        Scanner SK = new Scanner(new File("Keys.txt"));
        Scanner SR = new Scanner(new File("Requests.txt"));
        Scanner SS = new Scanner(new File("Students.txt"));
        while(SC.hasNextLine()){
            TeacherList.flag = false;
            KeyList.flag =false;
            String[] S = SC.nextLine().split(" ");
            key = SK.next();
            this.insert(S[0]+" "+S[1], Integer.parseInt(S[2]),Integer.parseInt(S[3]), Integer.parseInt(S[4]), S[5], S[6]);
        }
        TeacherList.flag = true;
        KeyList.flag = true;
        while(SR.hasNextLine()){
            RequestList.flag = false;
            String[] J = SR.nextLine().split(" ");
            if(J.length==5){
                this.addRequest(Integer.parseInt(J[0]),J[1],J[2],Integer.parseInt(J[3]),Integer.parseInt(J[4]));
            }
        }
        RequestList.flag = true;
        while(SS.hasNextLine()){
            StudentList.flag = false;
            String[] L = SS.nextLine().split(" ");
            if(L.length==5){
                Request R = new Request(L[1],L[2],Integer.parseInt(L[3]),Integer.parseInt(L[4]));
                this.addStudent(Integer.parseInt(L[0]),R);
            }
        }
        StudentList.flag = true;
    }

    public void addRequest(int index,String area,String course, int expectedFees,int noOfDays) throws IOException {
        Teacher T = search(area,course).TeacherList.get(index);
        if(RequestMap.get(T)==null){
            RequestMap.put(T,new RequestList());
        }
        Request Re = new Request(area, course, expectedFees, noOfDays);
        RequestMap.get(T).insert(Re,index);
    }

    public void acceptRequest(int index,String area,String course,int ReqIndex) throws Exception {
        Teacher T = search(area, course).TeacherList.get(index);
        Request R = RequestMap.get(T).RequestList.get(ReqIndex);
        String result = fileToString("Requests.txt");
        String r = index+" "+R.area + " " + R.course + " " + R.expectedFees + " " + R.noOfDays + "\n";
        result = result.replaceFirst(r,"");
        FileWriter FW = new FileWriter("Requests.txt");
        FW.append(result);
        RequestMap.get(T).RequestList.remove(ReqIndex);
        addStudent(index,R);
    }

    public void addStudent(int index, Request R) throws IOException {
        Teacher T = search(R.area,R.course).TeacherList.get(index);
        if(StudentMap.get(T)==null){
            StudentMap.put(T,new StudentList());
        }
        StudentMap.get(T).insert(R , index);
    }

    public void insert(String name, int age,int years,int months,String area, String course) throws IOException {
        Teacher T = new Teacher(name,age,new Exp(years,months),area,course);
        int x = genASCII(area);
        if(AreaList.size()<10){
            x %= 13;
        }else{
            int d = AreaList.size() + (int) (AreaList.size()/3.0);
            int s = getPrime(d);
            x %= s;
        }
        if(AreaList.get(x)==null){
            AreaList.put(x,new CourseList());
        }
        AreaList.get(x).insert(T,genASCII(course));
    }
    public TeacherList search(String area,String course){
        int x = genASCII(area);
        if(AreaList.size()<10){
            x %= 13;
        }else{
            int d = AreaList.size() + (int) (AreaList.size()/3.0);
            int s = getPrime(d);
            x %= s;
        }
        if(AreaList.get(x)==null){
            return null;
        }
        return AreaList.get(x).search(genASCII(course));
    }
    private static int genASCII(String S){
        String A = S.toLowerCase();
        int x = 0;
        for(int i =0;i<A.length();i++){
            x += A.charAt(i);
        }
        return x;
    }
    public static int getPrime(int s){
        while (!isPrime(s)){
            s++;
        }
        return s;
    }
    private static boolean isPrime(int n){
        if(n<=1)
        {
            return false;
        }
        for(int i=2;i<=n/2;i++)
        {
            if((n%i)==0)
                return  false;
        }
        return true;
    }

    public static String fileToString(String filePath) throws Exception{
        String input = null;
        Scanner sc = new Scanner(new File(filePath));
        StringBuffer sb = new StringBuffer();
        while (sc.hasNextLine()) {
            input = sc.nextLine();
            sb.append(input);
        }
        return sb.toString();
    }
}
