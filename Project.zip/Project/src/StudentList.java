import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Stack;

public class StudentList {
    ArrayList<Request> StudentList = new ArrayList<Request>();
    static boolean flag = true;
    public void insert(Request R,int index) throws IOException {
        if(!find(R)){
            StudentList.add(R);
            if (flag) {
                FileWriter FW = new FileWriter("Students.txt", true);
                FW.write(index+" "+R.area + " " + R.course + " " + R.expectedFees + " " + R.noOfDays + "\n");
                FW.close();
            }
        }
    }
    public String toString(){
        StringBuilder x = new StringBuilder();
        for (Request request : StudentList) {
            x.append(request).append("\n");
        }
        return x.toString();
    }
    public boolean find(Request R){
        for (Request request : StudentList) {
            if (request.area.equals(R.area) && request.course.equals(R.course) && request.expectedFees == R.expectedFees && request.noOfDays == R.noOfDays) {
                return true;
            }
        }
        return false;
    }
}
