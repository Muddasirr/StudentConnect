import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class RequestList {
    ArrayList<Request> RequestList = new ArrayList<Request>();
    ArrayList<Integer> IndexList = new ArrayList<Integer>();
    static boolean flag = true;
    public void insert(Request R,int index) throws IOException {
        if(!find(R)){
            RequestList.add(R);
            IndexList.add(index);
            if (flag) {
                FileWriter FW = new FileWriter("Requests.txt", true);
                FW.write(index+" "+R.area + " " + R.course + " " + R.expectedFees + " " + R.noOfDays + "\n");
                FW.close();
            }
        }
    }
    public String toString(){
        StringBuilder x = new StringBuilder();
        int i = 0;
        for (Request request : RequestList) {
            i++;
            x.append((i) + " ").append(request).append("\n");
        }
        return x.toString();
    }
    public boolean find(Request R){
        for (Request request : RequestList) {
            if (request.area.equals(R.area) && request.course.equals(R.course) && request.expectedFees == R.expectedFees && request.noOfDays == R.noOfDays) {
                return true;
            }
        }
        return false;
    }
}
