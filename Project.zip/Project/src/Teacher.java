import java.io.IOException;

public class Teacher {
    String name;
    int age;
    Exp experience;
    String area;
    String course;

    public Teacher(String name, int age, Exp experience, String area, String course) throws IOException {
        this.name = name;
        this.age = age;
        this.experience = experience;
        this.area = area;
        this.course = course;
    }

    public String toString(){
        return "Name: "+this.name+" Age: "+this.age + " Experience: " + this.experience;
    }
}class Exp{
    int years;
    int months;

    public Exp(int years, int months) {
        this.years = years;
        this.months = months;
    }

    public String toString() {
        return this.years + " Years "+ this.months + " Months";
    }
}
