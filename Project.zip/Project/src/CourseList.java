import java.io.IOException;
import java.util.HashMap;

public class CourseList {
    HashMap<Integer,TeacherList> CourseList = new HashMap<Integer, TeacherList>();
    public void insert(Teacher T,int code) throws IOException {
        int x = code;
        if(CourseList.size()<10){
            x %= 13;
        }else{
            int d = CourseList.size() + (int) (CourseList.size()/3.0);
            int s = Directory.getPrime(d);
            x %= s;
        }
        if(CourseList.get(x)==null){
            CourseList.put(x,new TeacherList());
        }
        CourseList.get(x).insert(T);
    }
    public TeacherList search(int code){
        int x = code;
        if(CourseList.size()<10){
            x %= 13;
        }else{
            int d = CourseList.size() + (int) (CourseList.size()/3.0);
            int s = Directory.getPrime(d);
            x %= s;
        }
        if(CourseList.get(x)==null){
            return null;
        }
        return CourseList.get(x);
    }
}
